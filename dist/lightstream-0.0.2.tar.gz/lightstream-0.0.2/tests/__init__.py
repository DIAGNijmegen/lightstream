# Avoid ModuleNotFoundError

import sys
from lightstream.scnn import StreamingCNN

sys.path.append("./lightstream")


print("meow")
