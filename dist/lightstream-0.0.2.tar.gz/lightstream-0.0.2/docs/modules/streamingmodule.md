# StreamingModule

::: modules.streaming.StreamingModule
    options:
      docstring_section_style: table