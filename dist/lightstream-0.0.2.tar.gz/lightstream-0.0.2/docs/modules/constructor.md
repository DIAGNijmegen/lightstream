# StreamingModule

::: modules.constructor.StreamingConstructor
    options:
      docstring_section_style: table