# BaseModule

::: modules.imagenet_template.ImageNetClassifier
