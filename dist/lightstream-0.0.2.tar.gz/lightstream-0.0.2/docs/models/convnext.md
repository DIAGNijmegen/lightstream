# Resnet

::: models.convnext.convnext.StreamingConvnext